/*
🧠 Created by Vyzen
🎵 TikTok   : @vyzen_7
🌐 Ch WhatsApp : https://whatsapp.com/channel/0029Vb6CHAjK5cDJGJssog3J
*/

import axios from 'axios'
import { Sticker } from 'wa-sticker-formatter'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `Contoh:\n${usedPrefix + command} halo`, m)

  try {
    let loading = await conn.reply(m.chat, 'sabar ygy otw nih...', m)

    let url = `https://furrbrats.vercel.app/generate?text=${encodeURIComponent(text)}&chara=1&align=center`

    let res = await axios.get(url, { responseType: 'arraybuffer' })

    const sticker = new Sticker(res.data, {
      pack: 'yaya begitulah',
      author: 'vyzen',
      type: 'full',
      quality: 80
    })

    let buffer = await sticker.toBuffer()

    await conn.sendMessage(m.chat, { delete: loading.key })

    await conn.sendMessage(m.chat, { sticker: buffer }, { quoted: m })

  } catch (e) {
    console.error(e)
    m.reply('Gagal cik 😹')
  }
}

handler.help = ['furbrat <text>']
handler.command = /^furbrat|furrbrat$/i
handler.tags = ['sticker']

export default handler