import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.prefix = ["."]

global.config = {
    owner: [
        ['62895326858840', 'Nahida MD', true],
['573238329287', 'Cuki? love u', true],
        ['639972895613', 'zen ajg', true]
    ],

    pairingNumber: "62895326858840",
    pairingAuth: true,

    gris: '`',

    watermark: 'Nahida - MultiDevice',
    author: 'ZenzzXD',

    loading: 'Mohon ditunggu...',
    errorMsg: 'Error :)',
    stickpack: 'Made With',
    stickauth: 'Nahida-Multidevice'
}

global.loading = (m, conn, back = false) => {
    if (!back) {
        return conn.sendReact(m.chat, "🕒", m.key)
    } else {
        return conn.sendReact(m.chat, "", m.key)
    }
}

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'config.js'"))
    import(`${file}?update=${Date.now()}`)
})