let handler = async (m, { conn, usedPrefix }) => {

  const prefix = usedPrefix || "."

  let text = `Halo *@${m.sender.split("@")[0]}* 👋🏻
Ini adalah menu dari simple bot by cuki

› LIST FITUR:
▢ tt / tiktok
▢ upswgc
▢ brat
▢ bratvid`

  await conn.reply(m.chat, text, m, {
    mentions: [m.sender]
  })
}

handler.help = ["menu"]
handler.tags = ["main"]
handler.command = ["menu", "help"]
export default handler